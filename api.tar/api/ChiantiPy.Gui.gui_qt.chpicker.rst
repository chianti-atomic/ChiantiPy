

chpicker
=============================

.. currentmodule:: ChiantiPy.Gui.gui_qt

.. autofunction:: chpicker


gffintRead
=============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: gffintRead


gffRead
==========================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: gffRead
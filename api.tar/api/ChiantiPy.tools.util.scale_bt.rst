

scale_bt
=============================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: scale_bt
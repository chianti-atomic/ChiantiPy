

scupsRead
============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: scupsRead
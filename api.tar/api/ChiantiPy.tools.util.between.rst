

between
============================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: between
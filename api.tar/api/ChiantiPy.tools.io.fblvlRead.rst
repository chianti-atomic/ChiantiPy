

fblvlRead
============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: fblvlRead
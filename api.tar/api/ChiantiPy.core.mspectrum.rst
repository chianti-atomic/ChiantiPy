

mspectrum
========================

.. currentmodule:: ChiantiPy.core

.. autoclass:: mspectrum
   :show-inheritance:

   
     
   

   
   
   

   
   
   

   
   
   

   
   
   
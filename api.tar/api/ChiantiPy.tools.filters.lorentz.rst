

lorentz
===============================

.. currentmodule:: ChiantiPy.tools.filters

.. autofunction:: lorentz


choice2Dialog
==================================

.. currentmodule:: ChiantiPy.Gui.gui_cl

.. autoclass:: choice2Dialog
   :show-inheritance:

   
     
   

   
   
   

   
   
   

   
   
   

   
   
   
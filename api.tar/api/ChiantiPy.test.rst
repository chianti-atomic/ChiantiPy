

test
==============

.. currentmodule:: ChiantiPy

.. autofunction:: test
autoRead
========

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: autoRead



zion2spectroscopic
=======================================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: zion2spectroscopic


cireclvlRead
===============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: cireclvlRead
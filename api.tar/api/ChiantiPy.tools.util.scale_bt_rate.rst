

scale_bt_rate
==================================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: scale_bt_rate
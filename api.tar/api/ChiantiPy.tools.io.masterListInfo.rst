

masterListInfo
=================================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: masterListInfo


blackStar
=================================

.. currentmodule:: ChiantiPy.tools.sources

.. autoclass:: blackStar
   :show-inheritance:

   
     
   

   
   
   

   
   

   .. rubric:: Methods Summary

   .. autosummary::
   
      ~blackStar.incident

   
   

   
   
   

   
   

   .. rubric:: Methods Documentation

   
   .. automethod:: incident

   
   
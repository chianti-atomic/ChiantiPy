rrLossRead
==========

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: rrLossRead

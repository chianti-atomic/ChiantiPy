

descale_bti
================================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: descale_bti
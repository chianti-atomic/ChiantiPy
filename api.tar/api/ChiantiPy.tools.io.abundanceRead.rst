

abundanceRead
================================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: abundanceRead
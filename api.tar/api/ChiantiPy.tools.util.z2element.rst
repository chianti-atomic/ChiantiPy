

z2element
==============================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: z2element
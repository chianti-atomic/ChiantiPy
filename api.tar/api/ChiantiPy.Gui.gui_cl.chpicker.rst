

chpicker
=============================

.. currentmodule:: ChiantiPy.Gui.gui_cl

.. autofunction:: chpicker
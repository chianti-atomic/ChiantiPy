

FortranRecordWriter
===========================================

.. currentmodule:: ChiantiPy.fortranformat

.. autoclass:: FortranRecordWriter
   :show-inheritance:

   
     
   

   
   

   .. rubric:: Attributes Summary

   .. autosummary::
   
      ~FortranRecordWriter.format

   
   

   
   

   .. rubric:: Methods Summary

   .. autosummary::
   
      ~FortranRecordWriter.get_format
      ~FortranRecordWriter.set_format
      ~FortranRecordWriter.write

   
   

   
   

   .. rubric:: Attributes Documentation

   
   .. autoattribute:: format

   
   

   
   

   .. rubric:: Methods Documentation

   
   .. automethod:: get_format
   .. automethod:: set_format
   .. automethod:: write

   
   
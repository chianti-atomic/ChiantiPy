

wgfaWrite
============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: wgfaWrite
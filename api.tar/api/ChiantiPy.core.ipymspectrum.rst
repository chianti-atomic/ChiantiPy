

ipymspectrum
===========================

.. currentmodule:: ChiantiPy.core

.. autoclass:: ipymspectrum
   :show-inheritance:

   
     
   

   
   
   

   
   
   

   
   
   

   
   
   
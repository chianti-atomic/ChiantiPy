

boxcar
==============================

.. currentmodule:: ChiantiPy.tools.filters

.. autofunction:: boxcar
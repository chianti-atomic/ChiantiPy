voigt
=====

.. currentmodule:: ChiantiPy.tools.filters

.. autofunction:: voigt

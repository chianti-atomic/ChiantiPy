

convertName
================================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: convertName
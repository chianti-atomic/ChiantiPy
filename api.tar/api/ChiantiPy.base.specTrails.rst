

specTrails
=========================

.. currentmodule:: ChiantiPy.base

.. autoclass:: specTrails
   :show-inheritance:

   
     
   

   
   
   

   
   

   .. rubric:: Methods Summary

   .. autosummary::
   
      ~specTrails.convolve
      ~specTrails.ionGate
      ~specTrails.lineSpectrumPlot
      ~specTrails.spectrumPlot

   
   

   
   
   

   
   

   .. rubric:: Methods Documentation

   
   .. automethod:: convolve
   .. automethod:: ionGate
   .. automethod:: lineSpectrumPlot
   .. automethod:: spectrumPlot

   
   
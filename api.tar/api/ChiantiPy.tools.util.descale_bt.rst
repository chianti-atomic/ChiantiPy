

descale_bt
===============================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: descale_bt


ioneqRead
============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: ioneqRead


elvlcWrite
=============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: elvlcWrite
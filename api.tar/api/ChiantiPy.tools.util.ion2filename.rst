

ion2filename
=================================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: ion2filename
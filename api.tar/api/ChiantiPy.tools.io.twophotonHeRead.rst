

twophotonHeRead
==================================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: twophotonHeRead
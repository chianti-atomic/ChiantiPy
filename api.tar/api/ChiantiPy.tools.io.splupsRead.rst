

splupsRead
=============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: splupsRead
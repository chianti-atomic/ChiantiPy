

itohRead
===========================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: itohRead
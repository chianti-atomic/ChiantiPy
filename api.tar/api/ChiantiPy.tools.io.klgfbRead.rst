

klgfbRead
============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: klgfbRead


zion2name
==============================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: zion2name
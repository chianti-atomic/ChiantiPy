

twophotonHRead
=================================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: twophotonHRead
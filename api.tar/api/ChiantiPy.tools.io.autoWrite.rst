autoWrite
=========

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: autoWrite

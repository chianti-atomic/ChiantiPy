

gaussianR
=================================

.. currentmodule:: ChiantiPy.tools.filters

.. autofunction:: gaussianR
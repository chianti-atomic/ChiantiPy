

doIonQ
=============================

.. currentmodule:: ChiantiPy.tools.mputil

.. autofunction:: doIonQ
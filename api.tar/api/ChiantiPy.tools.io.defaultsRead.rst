

defaultsRead
===============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: defaultsRead
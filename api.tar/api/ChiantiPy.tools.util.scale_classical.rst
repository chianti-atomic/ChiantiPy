

scale_classical
====================================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: scale_classical
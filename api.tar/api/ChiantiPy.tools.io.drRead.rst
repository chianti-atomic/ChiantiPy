

drRead
=========================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: drRead
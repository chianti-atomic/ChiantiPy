

masterListRead
=================================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: masterListRead
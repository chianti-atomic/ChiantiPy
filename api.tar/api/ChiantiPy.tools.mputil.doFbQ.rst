

doFbQ
============================

.. currentmodule:: ChiantiPy.tools.mputil

.. autofunction:: doFbQ
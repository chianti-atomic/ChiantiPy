

splomRead
============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: splomRead
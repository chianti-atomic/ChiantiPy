

qrp
========================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: qrp
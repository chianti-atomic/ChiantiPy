

zion2localFilename
=======================================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: zion2localFilename
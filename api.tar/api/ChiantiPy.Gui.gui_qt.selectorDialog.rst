

selectorDialog
===================================

.. currentmodule:: ChiantiPy.Gui.gui_qt

.. autoclass:: selectorDialog
   :show-inheritance:

   
     
   

   
   
   

   
   

   .. rubric:: Methods Summary

   .. autosummary::
   
      ~selectorDialog.accept
      ~selectorDialog.reject

   
   

   
   
   

   
   

   .. rubric:: Methods Documentation

   
   .. automethod:: accept
   .. automethod:: reject

   
   


splomDescale
=================================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: splomDescale
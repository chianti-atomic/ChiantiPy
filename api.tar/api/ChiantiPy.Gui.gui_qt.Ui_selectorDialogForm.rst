

Ui_selectorDialogForm
==========================================

.. currentmodule:: ChiantiPy.Gui.gui_qt

.. autoclass:: Ui_selectorDialogForm
   :show-inheritance:

   

   
   
   

   
   

   .. rubric:: Methods Summary

   .. autosummary::
   
      ~Ui_selectorDialogForm.retranslateUi
      ~Ui_selectorDialogForm.setupUi

   
   

   
   
   

   
   

   .. rubric:: Methods Documentation

   
   .. automethod:: retranslateUi
   .. automethod:: setupUi

   
   
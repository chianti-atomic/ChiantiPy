

vernerRead
=============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: vernerRead
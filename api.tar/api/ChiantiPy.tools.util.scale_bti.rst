

scale_bti
==============================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: scale_bti
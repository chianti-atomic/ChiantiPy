

diRead
=========================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: diRead
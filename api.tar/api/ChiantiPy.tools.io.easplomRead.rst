

easplomRead
==============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: easplomRead
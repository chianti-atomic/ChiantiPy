

gaussian
================================

.. currentmodule:: ChiantiPy.tools.filters

.. autofunction:: gaussian


eaRead
=========================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: eaRead
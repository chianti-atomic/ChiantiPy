

zion2filename
==================================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: zion2filename
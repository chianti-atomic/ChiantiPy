

zion2name
============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: zion2name


continuum
========================

.. currentmodule:: ChiantiPy.core

.. autoclass:: continuum
   :show-inheritance:

   
     
   

   
   
   

   
   

   .. rubric:: Methods Summary

   .. autosummary::
   
      ~continuum.freeBound
      ~continuum.freeBoundEmiss
      ~continuum.freeBoundLoss
      ~continuum.freeFree
      ~continuum.freeFreeEmiss
      ~continuum.freeFreeLoss
      ~continuum.ioneqOne
      ~continuum.itoh
      ~continuum.klgfbInterp
      ~continuum.sutherland
      ~continuum.vernerCross

   
   

   
   
   

   
   

   .. rubric:: Methods Documentation

   
   .. automethod:: freeBound
   .. automethod:: freeBoundEmiss
   .. automethod:: freeBoundLoss
   .. automethod:: freeFree
   .. automethod:: freeFreeEmiss
   .. automethod:: freeFreeLoss
   .. automethod:: ioneqOne
   .. automethod:: itoh
   .. automethod:: klgfbInterp
   .. automethod:: sutherland
   .. automethod:: vernerCross

   
   
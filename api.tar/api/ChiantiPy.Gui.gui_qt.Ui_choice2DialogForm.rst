

Ui_choice2DialogForm
=========================================

.. currentmodule:: ChiantiPy.Gui.gui_qt

.. autoclass:: Ui_choice2DialogForm
   :show-inheritance:

   

   
   
   

   
   

   .. rubric:: Methods Summary

   .. autosummary::
   
      ~Ui_choice2DialogForm.retranslateUi
      ~Ui_choice2DialogForm.setupUi

   
   

   
   
   

   
   

   .. rubric:: Methods Documentation

   
   .. automethod:: retranslateUi
   .. automethod:: setupUi

   
   
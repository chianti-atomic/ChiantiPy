

versionRead
==============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: versionRead


selectorDialog
===================================

.. currentmodule:: ChiantiPy.Gui.gui_cl

.. autoclass:: selectorDialog
   :show-inheritance:

   
     
   

   
   
   

   
   
   

   
   
   

   
   
   
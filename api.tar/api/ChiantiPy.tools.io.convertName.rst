

convertName
==============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: convertName
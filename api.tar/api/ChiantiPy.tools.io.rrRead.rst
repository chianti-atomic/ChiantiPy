

rrRead
=========================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: rrRead


wgfaRead
===========================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: wgfaRead
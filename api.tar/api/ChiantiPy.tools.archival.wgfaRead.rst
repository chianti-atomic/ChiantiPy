

wgfaRead
=================================

.. currentmodule:: ChiantiPy.tools.archival

.. autofunction:: wgfaRead


ipRead
=========================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: ipRead
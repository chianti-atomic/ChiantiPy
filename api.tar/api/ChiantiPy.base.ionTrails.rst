

ionTrails
========================

.. currentmodule:: ChiantiPy.base

.. autoclass:: ionTrails
   :show-inheritance:

   

   
   
   

   
   

   .. rubric:: Methods Summary

   .. autosummary::
   
      ~ionTrails.intensityList
      ~ionTrails.intensityPlot
      ~ionTrails.intensityRatio
      ~ionTrails.intensityRatioSave

   
   

   
   
   

   
   

   .. rubric:: Methods Documentation

   
   .. automethod:: intensityList
   .. automethod:: intensityPlot
   .. automethod:: intensityRatio
   .. automethod:: intensityRatioSave

   
   


bunch
====================

.. currentmodule:: ChiantiPy.core

.. autoclass:: bunch
   :show-inheritance:

   
     
   

   
   
   

   
   
   

   
   
   

   
   
   
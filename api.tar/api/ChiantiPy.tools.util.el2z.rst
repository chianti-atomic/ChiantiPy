

el2z
=========================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: el2z
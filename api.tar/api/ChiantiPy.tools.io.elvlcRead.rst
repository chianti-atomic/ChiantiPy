

elvlcRead
============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: elvlcRead
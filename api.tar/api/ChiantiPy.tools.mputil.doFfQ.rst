

doFfQ
============================

.. currentmodule:: ChiantiPy.tools.mputil

.. autofunction:: doFfQ


ioneq
====================

.. currentmodule:: ChiantiPy.core

.. autoclass:: ioneq
   :show-inheritance:

   
     
   

   
   
   

   
   

   .. rubric:: Methods Summary

   .. autosummary::
   
      ~ioneq.calculate
      ~ioneq.load
      ~ioneq.plot

   
   

   
   
   

   
   

   .. rubric:: Methods Documentation

   
   .. automethod:: calculate
   .. automethod:: load
   .. automethod:: plot

   
   
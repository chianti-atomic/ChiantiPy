

choice2Dialog
==================================

.. currentmodule:: ChiantiPy.Gui.gui_qt

.. autoclass:: choice2Dialog
   :show-inheritance:

   
     
   

   
   
   

   
   

   .. rubric:: Methods Summary

   .. autosummary::
   
      ~choice2Dialog.accept
      ~choice2Dialog.reject

   
   

   
   
   

   
   

   .. rubric:: Methods Documentation

   
   .. automethod:: accept
   .. automethod:: reject

   
   
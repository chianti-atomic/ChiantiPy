

blackbody
=================================

.. currentmodule:: ChiantiPy.tools.sources

.. autofunction:: blackbody
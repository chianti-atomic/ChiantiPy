

elvlcWrite
===================================

.. currentmodule:: ChiantiPy.tools.archival

.. autofunction:: elvlcWrite
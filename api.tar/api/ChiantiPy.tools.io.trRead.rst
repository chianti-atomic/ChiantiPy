

trRead
=========================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: trRead
elvlcRead
=========

.. currentmodule:: ChiantiPy.tools.archival

.. autofunction:: elvlcRead

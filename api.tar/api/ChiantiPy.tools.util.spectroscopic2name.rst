

spectroscopic2name
=======================================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: spectroscopic2name
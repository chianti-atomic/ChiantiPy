

zion2dir
=============================

.. currentmodule:: ChiantiPy.tools.util

.. autofunction:: zion2dir


photoxRead
=============================

.. currentmodule:: ChiantiPy.tools.io

.. autofunction:: photoxRead
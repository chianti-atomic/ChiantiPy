

moffat
==============================

.. currentmodule:: ChiantiPy.tools.filters

.. autofunction:: moffat
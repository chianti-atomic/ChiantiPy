

spectrum
=======================

.. currentmodule:: ChiantiPy.core

.. autoclass:: spectrum
   :show-inheritance:

   
     
   

   
   
   

   
   
   

   
   
   

   
   
   
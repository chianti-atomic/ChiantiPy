

FortranRecordReader
===========================================

.. currentmodule:: ChiantiPy.fortranformat

.. autoclass:: FortranRecordReader
   :show-inheritance:

   
     
   

   
   

   .. rubric:: Attributes Summary

   .. autosummary::
   
      ~FortranRecordReader.format

   
   

   
   

   .. rubric:: Methods Summary

   .. autosummary::
   
      ~FortranRecordReader.get_format
      ~FortranRecordReader.match
      ~FortranRecordReader.read
      ~FortranRecordReader.set_format

   
   

   
   

   .. rubric:: Attributes Documentation

   
   .. autoattribute:: format

   
   

   
   

   .. rubric:: Methods Documentation

   
   .. automethod:: get_format
   .. automethod:: match
   .. automethod:: read
   .. automethod:: set_format

   
   